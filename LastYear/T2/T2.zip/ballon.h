//This is header file for the model: ballon
// Positions: 241
// vt's: 284
// Normals: 356
// Faces: 428
// Vertices: 1284
const int ballonVertices;
const float ballonPositions[3852];
const float ballonTexels[2568];
const float ballonNormals[3852];
